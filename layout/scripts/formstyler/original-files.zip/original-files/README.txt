jQuery Form Styler <sup>[1.3.4](http://dimox.name/jquery-form-styler/#log)</sup>
==================

jQuery-плагин для стилизации элементов html-форм:

* `<input type="checkbox">`
* `<input type="radio">`
* `<input type="file">`
* `<select>`

Ссылки
------

* [Страница с примерами] (http://dimox.github.com/formStyler/demo/)
* [Домашняя страница плагина] (http://dimox.name/jquery-form-styler/)
