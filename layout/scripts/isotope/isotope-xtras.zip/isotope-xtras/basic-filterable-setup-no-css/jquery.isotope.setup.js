(function ($) {
    "use strict";
    $(window).load(function () {
        if ($.fn.isotope) {
            $('.isotope-wrapper').each(function () {
                var $this = $(this);
                var $container = $this.find('.isotope-collection ul:eq(0)');
                var $filters = $this.find('.isotope-filters ul:eq(0)');
                /* Start Isotope */
                $container.isotope({
                    resizable: false,
                    containerStyle: {
                        position: 'relative',
                        overflow: 'visible'
                    },
                    itemSelector: 'li',
                    layoutMode: 'fitRows'
                });
                /* Set up filters */
                $filters.find('a').click(function () {
                    /* Add or remove classes for styling */
                    $filters.find('li.current').removeClass('current');
                    $(this).parent('li').addClass('current');
                    /* Filter Attribute */
                    var selector = $(this).attr('data-filter');
                    $container.isotope({
                        filter: selector
                    });
                    return false;
                });
                if (document.location.hash) {
                    var filter = document.location.hash.replace('#', '');
                    var $filter = $filters.find('a[data-filter=".' + filter + '"]');
                    if ($filter.length > 0) {
                        $filters.find('li.current').removeClass('current');
                        $filter.parents('li').addClass('current');
                        $container.isotope({
                            filter: '.' + filter
                        });
                    }
                }
            });
            /* smartresize */
            $(window).smartresize(function () {
                /* Leave it empty so that column width can be controlled from CSS  */
                $('.isotope-wrapper .isotope-collection ul:eq(0)').isotope({});
            });
        }
    });
})(jQuery);